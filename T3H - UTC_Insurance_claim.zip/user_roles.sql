INSERT INTO insuranceclaim.user_roles (user_id, role_id) VALUES (1, 1);
INSERT INTO insuranceclaim.user_roles (user_id, role_id) VALUES (2, 2);
