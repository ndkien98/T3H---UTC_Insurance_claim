INSERT INTO insuranceclaim.roles (id, created_by, deleted, last_modified_by, name, code, created_date, last_modified_date) VALUES (1, 'admin', false, 'admin', 'Quản trị viên', 'ADMIN', null, null);
INSERT INTO insuranceclaim.roles (id, created_by, deleted, last_modified_by, name, code, created_date, last_modified_date) VALUES (2, 'admin', false, 'admin', 'Nhân viên', 'USER', null, null);
