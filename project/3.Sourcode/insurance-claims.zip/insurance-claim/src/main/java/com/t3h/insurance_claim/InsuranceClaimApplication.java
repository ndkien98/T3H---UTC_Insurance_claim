package com.t3h.insurance_claim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsuranceClaimApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsuranceClaimApplication.class, args);
	}

}
